const seed=[{name:'50ml Perfume',price:'₦25,000',desc:'Long lasting fragrance',img:''}];
let products=JSON.parse(localStorage.getItem('fvr_products')||'null')||seed;
function save(){localStorage.setItem('fvr_products',JSON.stringify(products));}
function render(){const c=document.getElementById('products');if(!c)return;c.innerHTML='';products.forEach(p=>{const d=document.createElement('div');d.className='card';d.innerHTML=(p.img?`<img src="${p.img}">`:`<div class=ph>FVRScent</div>`)+`<h3>${p.name}</h3><b>${p.price}</b><p>${p.desc}</p><a href="https://wa.me/2348038994003?text=I'm%20interested%20in%20${encodeURIComponent(p.name)}">Order on WhatsApp</a>`;c.appendChild(d);});}
function addProduct(){products.unshift({name:name.value,price:price.value,desc:desc.value,img:img.value});save();location.href='index.html';}
render();